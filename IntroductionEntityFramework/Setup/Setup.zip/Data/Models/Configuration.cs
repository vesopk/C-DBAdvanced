﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst.Data.Models
{
    static class Configuration
    {
        public const string connectionString = @"Server= .;Database=SoftUni;Integrated Security=True;";
    }
}
