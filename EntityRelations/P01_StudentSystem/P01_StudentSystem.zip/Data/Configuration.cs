﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystem;Integrated Security=true";
    }
}
